package dictionary;


public class DirectoryRun {
	public static void main(String[] args) {
		Directory my;
		my = new Directory();
		new SwingUI(my);
	}
}
